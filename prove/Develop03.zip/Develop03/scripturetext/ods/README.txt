kjv-scriptures.ods - Holy Bible

lds-scriptures.ods - Holy Bible, Book of Mormon, Doctrine & Covenants, Pearl
of Great Price
