Documentation: https://scriptures.nephi.org/json
