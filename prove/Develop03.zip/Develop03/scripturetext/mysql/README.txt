Documentation: https://scriptures.nephi.org/mysql
