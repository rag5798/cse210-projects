kjv-scriptures.txt - Holy Bible

lds-scriptures.txt - Holy Bible, Book of Mormon, Doctrine & Covenants, Pearl
of Great Price
